## Stryker
